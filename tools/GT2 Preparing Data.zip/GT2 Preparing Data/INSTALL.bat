@echo off
setlocal
cd /d "%~dp0"
rem Uses the prebuilt tools in \tools (no compiler needed). Asks for discs and HD level, then writes the data to \runtime.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" -NoBuild -BuildDir "%~dp0tools" %*
if errorlevel 1 (
  echo Installation failed. See the error above.
  pause
  exit /b 1
)
pause
