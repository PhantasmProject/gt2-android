# GT2 Preparing Data

Windows tool that extracts and converts data from your own GT2 discs
for the Android port.

**INSTALL.bat** - pick your GT2 disc image(s) (Arcade and/or Simulation,
BIN/CUE/ISO/ZIP) and the HD level (original / HD menus / HD menus + movies).
Output goes to `runtime\`. Copy that data to the Android device as the port requires.

Prebuilt tools are in `tools\`; sources are in `src\`, `tools\*\`,
`scripts\`, `db\` (build with `build.cmd`).
